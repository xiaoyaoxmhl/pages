const models = require('./index');
const  branchs = models.getModel('branchs');


module.exports = {
    branchs
}