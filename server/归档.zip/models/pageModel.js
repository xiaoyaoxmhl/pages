const models = require('./index');
const projects = models.getModel('projects');


module.exports = {
    projects
}