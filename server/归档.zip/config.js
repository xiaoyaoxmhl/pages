const mongoConfig = {
    url: 'mongodb://localhost:27017/pages',

};

module.exports = {
    mongoConfig
}